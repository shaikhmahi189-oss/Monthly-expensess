MONTHLY HISAB - Android APK build guide (mobile-only)

Aapka HTML Android WebView app mein package kiya gaya hai.
Offline support ke liye Tailwind CSS build time par generate hoti hai; Chart.js aur Font Awesome
assets APK ke andar download/copy hote hain. App chalne ke waqt internet ki zaroorat nahi honi chahiye.

APK banane ke liye:
1. GitHub account mein naya PUBLIC ya PRIVATE repository banayein.
2. Is ZIP ko extract karke is folder ke saare files repository mein upload karein.
3. GitHub repository kholein -> Actions tab -> "Build Monthly Hisab APK".
4. "Run workflow" dabayein.
5. Build complete hone par workflow run ke Artifacts section mein "Monthly-Hisab-APK" download karein.
6. ZIP artifact extract karein. app-debug.apk ko Android phone par install karein.
7. Android prompt aaye to browser/files app ke liye "Install unknown apps" allow karein.

IMPORTANT:
- Is project mein aapke supplied HTML/JavaScript features preserve kiye gaye hain.
- LocalStorage WebView DOM storage mein save hota hai. App uninstall/clear data karne se local data mit sakta hai.
- Pehli APK build ke liye GitHub Actions ko internet chahiye; installed app ke normal use ke liye bundled assets local hain.
- CSV export on Android WebView device/browser version ke hisaab se test karna hoga.
- APK abhi build nahi hui hai; GitHub Actions se build karni hogi.
